package review_fileIO;



public class EchoWords {
	//The command line arguments are passed to your program inside
	//the args array.
	public static void main(String[] args) {
		
		//First check how many command line arguments
		//were provided
		System.out.printf("There are %d command line arguments.\n", 
				 args.length );
		
		//Then print all the arguments to the console one per line
		for (int i = 0; i < args.length; i++ ) {
			System.out.println(args[i]);
		}

		//We can also print them in reverse order on a single line
//		System.out.print( "revese: " );
//		for (int i = args.length - 1; i>= 0; i-- ) {
//			System.out.print(args[i]);
//		}
//		System.out.println();		
	}

}

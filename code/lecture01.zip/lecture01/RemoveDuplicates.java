package lecture01;

import java.util.ArrayList;

public class RemoveDuplicates {

	public static void main(String[] args) {
		String [] list = {"Paris", "Paris", "Paris", "Rome", "Warsaw", "London", "London",
				"Amsterdam"}; 
		ArrayList <String> aList = new ArrayList<String> ();
		for (int i =0;   i < list.length; i++){
			aList.add(list[i]);
		}
		
		System.out.println(aList);
		
		removeDup(aList);

		System.out.println(aList);
		
	}
	
	public static boolean removeDup(ArrayList<String> a){

		int i;
		int j;
		boolean judge=false;
		for(i=0;i<a.size();i++){
			for(j=i+1;j<a.size();j++){
				if(a.get(i).equals(a.get(j))){
					a.remove(j);
					judge = true;
					i--;
				}
				else{
					break;
				}
			}
		}
		return judge;
	}

}

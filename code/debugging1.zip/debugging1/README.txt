This package (debugging1) is meant to take you through the exercise of debugging.
There are several bugs (more than 5) that you will have to fix.

The final SongManager should find a song from the list and return it's title, review information, and shuffle it.
A "shuffled" song should not play in sequence.

The code is set up to create a playlist then shuffle the playlist.
A new playlist should NOT be repeated ever and a shuffle combination should always differ (assuming that you have at least 10 songs).

Your job is to:

1. Create a list of review and songs (at least 10) with various ratings.
2. Debug and fix the current errors and make sure that your SongManager works.
3. Test out several times that the playlist does not repeat and the shuffle either.

Here are the things to remember:

  - If I create the playlist two times, I should NOT get the same songs.
  - For songs in current playlist, make sure to shuffle them... (do NOT remove songs but the shuffle should not return the same thing every time).
  - Some example reviews can be gotten from here:
    http://www.allmusic.com/
  - Your playlist should have at least 10 songs from allmusic.com. each song should have at least one review along with it's stars.
  - You should be able to shuffle and not get the same list ever.
  - run the program and observe its behavior
  - if it crashes
  		- read the error message, 
  		- narrow down the lines of code that trigger the error 	
  		- create a breakpoint a few lines ahead of the error and run the program using the debugger
  		- examine values in variables and objects carefully to find any problem
  - if it produces incorrect results
  		- try to determine which part of the program is responsible for the final result
  		- backtrack through the code to determine which parts of the code
  		modify values
  		- create breakpoints at all locations that might affect the value of the final incorrect result
  		- run the program using the debugger
  		- examine the value careful and try to figure out when they become corrupt  